﻿using FinalLaboratorioII.entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalLaboratorioII.servicios
{
    internal class ServicioVenta
    {

        public ServicioVenta()
        {

        }

        public Venta crearVenta()
        {
            Console.WriteLine("Nueva Venta");





            return null;
        }





    }
}
