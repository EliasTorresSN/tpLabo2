﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalLaboratorioII.entidades.subEntidades
{
    internal class Camioneta : Vehiculo
    {
        public Camioneta() { }
    }
}
